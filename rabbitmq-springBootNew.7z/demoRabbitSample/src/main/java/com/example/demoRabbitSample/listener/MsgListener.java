package com.example.demoRabbitSample.listener;

import org.springframework.stereotype.Component;

@Component
public class MsgListener {

	 public void receiveMessage(String message) {
	       System.out.println("Received <" + message + ">");
	     
	    }
}
