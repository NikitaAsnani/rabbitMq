package com.example.demoRabbitSample.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoRabbitSample.DemoRabbitSampleApplication;

@RestController
public class AppController {

	 private RabbitTemplate rabbitTemplate;

	/**
	 * @param rabbitTemplate
	 */
	public AppController(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
	}
	 
	@RequestMapping("/")
	public String sendMsg() {
		rabbitTemplate.convertAndSend(DemoRabbitSampleApplication.SFG_MESSAGE_QUEUE, "hello world");
		return "send";
	}
}
