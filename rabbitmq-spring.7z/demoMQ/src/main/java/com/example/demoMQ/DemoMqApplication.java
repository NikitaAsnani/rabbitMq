package com.example.demoMQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMqApplication.class, args);
	}
}
